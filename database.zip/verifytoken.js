const TOKEN_KEY = "x4TvnEirxRETbVcqaL15dqMI115eNlp5y";
module.exports = TOKEN_KEY;